BOTAX Android - proyek sumber APK
=================================

Ini adalah proyek Android Studio untuk membungkus BOTAX menjadi aplikasi Android,
bukan lagi membuka file HTML melalui tab preview. UI BOTAX disimpan lokal di:
app/src/main/assets/index.html

Cara membuat APK:
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder BOTAX_Android.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan berada di app/build/outputs/apk/debug/app-debug.apk.

Catatan pemutaran:
- Pencarian katalog tetap memakai mekanisme yang sudah ada di BOTAX (YouTube Data API
  jika API key diisi, atau pencarian Piped jika tersedia).
- Pemutaran video memakai YouTube IFrame Player resmi di dalam WebView Android.
- Pemutaran membutuhkan koneksi internet dan harus dimulai oleh sentuhan pengguna.
- YouTube dapat membatasi video tertentu, wilayah, usia, atau pemutaran tertanam.
- Penambahan origin HTTPS appassets ditujukan membantu identifikasi embed pada WebView,
  tetapi tidak dapat menjamin semua video akan lolos kebijakan/konfigurasi YouTube.
- Proyek ini belum merupakan APK yang sudah dikompilasi; APK perlu dibangun melalui
  Android Studio atau Gradle dengan Android SDK terpasang.
